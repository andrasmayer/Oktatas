import {beers} from "./Components/data.js"

class buttons{
    constructor(){ 
        this.state = ""
        root.innerHTML += `
            <div class="controls">${ this.buttonComponent("load")    }</div>
            <div id="content"></div>
            `
        this.events()
    }
    buttonComponent(method){
        this.state = method
        this.btnList = {
            load:           `<button class="action"  current="load" next="sort" >Load the beers</button>`,
            sort:           `<button class="action"  current="sort" next="sort_reverse" >Sort by scrore</button>`,
            sort_reverse :   `<button class="action" current="sort_reverse" next="load" >Sort by scrore reverse</button>`,
        }
        return this.btnList[method]
    }
    beerTypeComponent(action){
        const content = document.getElementById("content")
        let items = ``
        const loadItems = (tmp_beers)=>{
            tmp_beers.forEach((itm,key)=>{
            
                items += `
                <div class="beer">
                <h1 class="torlendo">#${key+1}</h1>
                    <h2>${itm.name}</h2>
                    <h3>${itm.brewery}</h3>
                    <ul>Type: ${1}</ul>
                    <h4>Score: ${itm.score}</h4>
                    <h5>Abv: ${itm.abv}</h5>
                </div>`
            })
            content.innerHTML = items
        }

        let tmp_beers = []
        beers.forEach(itm=>{ tmp_beers.push(itm) })

        if(action == "load" ){ loadItems( tmp_beers ) }
        else if(action == "sort" ){ loadItems( tmp_beers.sort((a,b) => a.score - b.score) ) }
        else if(action == "sort_reverse" ){ loadItems( tmp_beers.sort((a,b) => b.score - a.score) ) }
    }
    events(){
        const controls = document.querySelector(".controls")
        const btnPool = document.querySelector(".action")
       
        btnPool.addEventListener("click",(e)=>{
            const next =    e.target.getAttribute("next")
            const current =    e.target.getAttribute("current")
            const nextBtn = this.btnList[next]
            controls.innerHTML = nextBtn
            this.beerTypeComponent(current)
            this.events()
        })
    }
}

const root = document.getElementById("root")
const btnList = new buttons()
